require 'class'
require 'app'

ofSetupOpenGL(1024, 768, OF_WINDOW)

ofRunApp(app)
